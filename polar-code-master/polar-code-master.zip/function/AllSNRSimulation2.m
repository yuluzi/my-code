function [SystemBERNum , SystemFERNum , SystemBER , SystemFER] =  ...
AllSNRSimulation2(N,K,ebn0,total_frame_num,max_frame_num,construction_method,   ...
bp_iter_num,scan_iter_num,scl_list_size,crc_size,decoder_tree_initial, G_set, B_set)
%SINGLESNRSIMULATION 此处显示有关此函数的摘要

%   还没改对比试验


    SystemBERNum = 0;
    SystemFERNum = 0;
    design_snr_dB = 0;%使用BA构造方法构造极坐标代码的参数
    sigma = 0.9;%使用GA构造方法构造极坐标代码的参数
    

    
    IsContinue = true;
    current_total_frame_num = 0;
    
    ExecutorConditions = zeros(5,2);%用于存储各个执行体当前运行状态 0/1  0：不在运行 1：在运行
    %第一列当前运行状态  其余列暂未用上
    
    ExecutorNames = ["1.SC decoder","2.BP decoder","3.SCAN decoder","4.SCL decoder","5.SSC decoder"];%存取每个执行体名称
    
    TotalExecutorsBERNum = zeros(5,5);%存取各个执行体在不同的信噪比条件下执行完所有帧后的的误码数
    % 例如：TotalExecutorsBERNum(executors(1),ebn0(1)) 代表第一个执行体在第一个信噪比条件下执行后得到的误码数
    
    TotalExecutorsFERNum = zeros(5,5);%存取各个执行体在不同的信噪比条件下执行完所有帧后的的误帧数
    % 例如：TotalExecutorsFERNum(executors(1),ebn0(1)) 代表第一个执行体在第一个信噪比条件下执行后得到的误帧数
    
    TotalExecutorsBER = zeros(5,5);%存取各个执行体在不同的信噪比条件下执行完所有帧后的的误码率
    % 例如：TotalExecutorsBER(executors(1),ebn0(1)) 代表第一个执行体在第一个信噪比条件下执行后得到的误码率
    
    TotalExecutorsFER = zeros(5,5);%存取各个执行体在不同的信噪比条件下执行完所有帧后的的误帧率
    % 例如：TotalExecutorsFER(executors(1),ebn0(1)) 代表第一个执行体在第一个信噪比条件下执行后得到的误帧率
    
    while IsContinue
        if current_total_frame_num>=total_frame_num
            break;
        else
            ExecutorsBERNum = zeros(5,5);%存取各个执行体在不同的信噪比条件下执行的误码数
            % 例如：ExecutorsBER(executors(1),ebn0(1)) 代表第一个执行体在第一个信噪比条件下执行后得到的误码数
            
            ExecutorsFERNum = zeros(5,5);%存取各个执行体在不同的信噪比条件下执行的误帧数
            % 例如：ExecutorsBER(executors(1),ebn0(1)) 代表第一个执行体在第一个信噪比条件下执行后得到的误帧数
            
            ExecutorsBER = zeros(5,5);%存取各个执行体在不同的信噪比条件下执行的误码率
            % 例如：ExecutorsBER(executors(1),ebn0(1)) 代表第一个执行体在第一个信噪比条件下执行后得到的误码率
            
            ExecutorsFER = zeros(5,5);%存取各个执行体在不同的信噪比条件下执行的误帧率
            % 例如：ExecutorsBER(executors(1),ebn0(1)) 代表第一个执行体在第一个信噪比条件下执行后得到的误帧率
            
            executors = [1,2,3,4,5];%对比试验执行体集

            % 选取3个执行体构成执行体集合
            executornum = 3; %input('请输入需要选取的执行体数量（请请输入最小为1，最大为5的正整数）：');
            [DHRExecutors,ExecutorConditions] = SwichExecutor(ExecutorConditions,executornum);   
            
            MinIndex = 0;

            MaxIndex = 0;  % 找到每个执行体在不同信噪比环境下执行后的的平均误码数中有最大的平均误码数的执行体索引
            
            %每个帧/块需要执行体集合中的每个执行体都执行一次
            for ii = 1:length(executors)
                
                switch executors(ii)
                    case 1
                        fprintf('\n running polar_SC_decode now！');
                        crc_size = 0;
                        initPC(N,K,construction_method,design_snr_dB,sigma,crc_size);
                    case 2
                        fprintf('\n running polar_BP_decode now！');
                        crc_size = 0;
                        initPC(N,K,construction_method,design_snr_dB,sigma,crc_size);
                    case 3
                        fprintf('\n running polar_SCAN_decode now！');
                        crc_size = 0;
                        initPC(N,K,construction_method,design_snr_dB,sigma,crc_size);
                    case 4
                        fprintf('\nrunning polar_SCL_decode now！');
                        initPC(N,K,construction_method,design_snr_dB,sigma,crc_size);
                    case 5
                        fprintf('\n running polar_SSC_decode now！');
                        crc_size = 0;
                        initPC(N,K,construction_method,design_snr_dB,sigma,crc_size);
                        [decoder_tree_initial, G_set, B_set] = intial_tree_G( );
                    otherwise
                        fprintf('\n invalid input!!!');
                        bp_iter_num = 60;
                        scan_iter_num = 8;
                        scl_list_size = 4;
                        crc_size = 0;
                end
            
                %不同信噪比情况下分别执行
                for j = 1:length(ebn0)
                        fprintf('\n Now running:%f  [%d of %d] \n\t Iteration-Counter: %53d',ebn0(j),j,length(ebn0),0);
                        tt=tic();%用于启动一个计时器以测量代码的执行时间。返回值tt是一个计时器对象，用于停止计时器并计算经过的时间 
                    %每次执行一个指定帧/块数
                    for l = current_total_frame_num + 1 : current_total_frame_num + max_frame_num
                        %每次先生成信息序列，然后执行，使每个执行体执行相同的信息序列
                        u = randi(2,1,K)-1; %Bernoulli(0.5);  伯努利分布 生成一个长度为K的随机二进制序列（0或1），每个元素的取值都是等概率的
                        %运行 得到误码数和误帧数
                        [ExecutorsBERNum(executors(ii),j),ExecutorsFERNum(executors(ii),j)] = RunABlock(N,K,u,executors(ii),ebn0(j),ExecutorsBERNum(executors(ii),j),ExecutorsFERNum(executors(ii),j),bp_iter_num,scan_iter_num,scl_list_size,decoder_tree_initial, G_set, B_set);
                        %计算误码数和误帧数
                        if l ==current_total_frame_num + max_frame_num
                            fprintf(' \n异构执行体：%7s   在信噪比为：%7d  的环境下从第%7d 个块执行到第%7d 个块的总误码数为：%7d ',ExecutorNames(executors(ii)),ebn0(j),l-max_frame_num+1,l,ExecutorsBERNum(executors(ii),j));
                            fprintf(' \n异构执行体：%7s   在信噪比为：%7d  的环境下从第%7d 个块执行到第%7d 个块的总误帧数为：%7d ',ExecutorNames(executors(ii)),ebn0(j),l-max_frame_num+1,l,ExecutorsFERNum(executors(ii),j));
                            fprintf('\n\t Total time taken: %.2f sec (%d samples)',toc(tt),l);
                            fprintf('\n');
                        end
                        
                    end
                    
                    %求出每个执行体执行所有帧后的总BERNum、FERNum
                    TotalExecutorsBERNum(executors(ii),j) = TotalExecutorsBERNum(executors(ii),j) + ExecutorsBERNum(executors(ii),j);
                    TotalExecutorsFERNum(executors(ii),j) = TotalExecutorsFERNum(executors(ii),j) + ExecutorsFERNum(executors(ii),j);

                    %计算每个执行体在不同信噪比下的BER、FER
                    ExecutorsBER(executors(ii),j) = ExecutorsBERNum(executors(ii),j)/(K*max_frame_num);
                    ExecutorsFER(executors(ii),j) = ExecutorsFERNum(executors(ii),j)/max_frame_num;

                    %求出出每个执行体执行所有帧后的总BER、FER
                    TotalExecutorsBER(executors(ii),j) = TotalExecutorsBER(executors(ii),j) + ExecutorsBER(executors(ii),j);
                    TotalExecutorsFER(executors(ii),j) = TotalExecutorsFER(executors(ii),j) + ExecutorsFER(executors(ii),j);
    
                end
            
            end
            
            

            % 找到最差执行体
            AvgBERs = mean(ExecutorsBERNum,2); %mean(数组名,2)计算每一行的平均值
            %AvgFERs = mean(ExecutorsFERNum,2);
            

            for i = 1:length(DHRExecutors)
                fprintf(' \n异构执行体：%7s  在不同信噪比下的平均误码数为：%7d  。 \n',ExecutorNames(DHRExecutors(i)) , AvgBERs(DHRExecutors(i)));
            end
            

            [MaxAvgBER,MaxIndex] = max (AvgBERs); % MaxAvgBER:找到每个执行体在不同信噪比环境下执行后的的平均误码数中最大的平均误码数
            fprintf(' \n异构执行体：%7s  在不同信噪比下的平均误码数最大，为：%7d  。 \n',ExecutorNames(MaxIndex) , MaxAvgBER);

            fprintf(' \n则异构执行体：%7s   不会在下一轮执行体选取中被选中。 \n',ExecutorNames(MaxIndex));
            
            %ExecutorConditions全部清零，以便下次选取
            for i = 1:5
                ExecutorConditions(i,1) = 0;
            end

            ExecutorConditions(MaxIndex,1) = 1;

            % 找到最优执行体，并将其误码数作为系统最终误码数
            %找到被选中的执行体的BER、FER的有效数据
            ValidExecutorsBERNum = ExecutorsBERNum(DHRExecutors(1),:);
            for i = 2:length(DHRExecutors)
                ValidExecutorsBERNum = [ValidExecutorsBERNum;ExecutorsBERNum(DHRExecutors(i),:)] ;
            end
            [MinBERs,BestBERExecutors] = min(ValidExecutorsBERNum,[],1);  %min(数组名,2)计算每一列的最小值
            [MinFERs,BestFERExecutors] = min(ValidExecutorsBERNum,[],1);  %min(数组名,2)计算每一列的最小值
            %计算系统的误码总数和误帧总数
            SystemBERNum = sum(MinBERs);
            SystemFERNum = sum(MinFERs);
            SystemBER = SystemBERNum/(total_frame_num*K);
            SystemFER = SystemFERNum/total_frame_num;
    
    
            current_total_frame_num = current_total_frame_num + max_frame_num;
    
        end
       
    end





end

