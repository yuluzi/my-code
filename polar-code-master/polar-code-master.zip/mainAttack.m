% 执行体按照执行最大帧数出错概率为error_factor发生随机故障

clear; tic;

addpath('function');
global PCparams;
    
n=PCparams.n; 




N = 256;%码长
K = 64:64:256;%信息位长度

Rm = 1;%BPSK
ebn0 = 0:0.25:4;%;%一组信噪比0

%min_frame_error's = 10;%30 最小错误帧数

construction_method = input('choose polar code construction method (need run the file in constructed fold firstly to constructed the code): 0---BhattaBound  1---GA\n');
%decoding_method = input('choose the decoding method: 1---SC  2---BP  3---SCAN  4---SCL 5---SSC\n');

max_frame_num = input('请输入每个执行体集执行的最大帧数：');%最大帧数
total_frame_num = input('请输入本次任务共需执行的总帧数：');%任务总帧数


SystemBERNum = 0; %系统误码总数，初始为0
SystemFERNum = 0; %系统误帧总数，初始为0

%初始化各个译码算法参数
disp('请输入各个译码器参数：');
bp_iter_num = input('\n input the iternum of the BP: at least 40 \n');
scan_iter_num = input('\n input the iternum of the SCAN: at least 1 \n');
scl_list_size = input('\n input the list size of the SCL: at least 1 \n');
crc_size = input('\n input the crc size of the SCL: at least 0 \n');
% node_num = 2^(n+1)-1;
% decoder_tree_initial = cell(1,node_num);
% G_set = cell(1,n+1);
% B_set = cell(1,n+1);
[decoder_tree_initial, G_set, B_set] = intial_tree_G( );

for jj = 1:length(K)
    Rc = K(jj)/N;%码率

    SystemBERNums = zeros(3,length(ebn0));%存取系统在不同的信噪比条件下执行的误码数
    % 例如：SystemBERNums(1,ebn0(1)) 代表系统在第一个信噪比条件下执行后得到的误码数
    
    SystemFERNums = zeros(3,length(ebn0));%存取系统在不同的信噪比条件下执行的误帧数
    % 例如：SystemFERNums(1,ebn0(1)) 代表系统在第一个信噪比条件下执行后得到的误帧数、
    
    SystemBERs = zeros(3,length(ebn0));%存取系统在不同的信噪比条件下执行的误码率
    % 例如：SystemBERs(1,ebn0(1)) 代表系统在第一个信噪比条件下执行后得到的误码率
    
    SystemFERs = zeros(3,length(ebn0));%存取系统在不同的信噪比条件下执行的误帧率
    % 例如：SystemFERs(1,ebn0(1)) 代表系统在第一个信噪比条件下执行后得到的误帧率
     
    ComparativeExecutorsBERNum = zeros(5,length(ebn0)); %对比试验的各个执行体在不同的信噪比条件下执行的误码数量
    % 例如：ComparativeExecutorsBERNum(executors(1),ebn0(1)) 代表对比试验的第一个执行体在第一个信噪比条件下执行后得到的误码数
    
    ComparativeExecutorsFERNum = zeros(5,length(ebn0));%对比试验的各个执行体在不同的信噪比条件下执行的误帧数量
    % 例如：ComparativeExecutorsBERNum(executors(1),ebn0(1)) 代表对比试验的第一个执行体在第一个信噪比条件下执行后得到的误帧数
    
    ComparativeExecutorsBER = zeros(5,length(ebn0));%对比试验的各个执行体在不同的信噪比条件下执行的误码率
    % 例如：ComparativeExecutorsBERNum(executors(1),ebn0(1)) 代表对比试验的第一个执行体在第一个信噪比条件下执行后得到的误码率
    
    ComparativeExecutorsFER = zeros(5,length(ebn0));%对比试验的各个执行体在不同的信噪比条件下执行的误帧率
    % 例如：ComparativeExecutorsBERNum(executors(1),ebn0(1)) 代表对比试验的第一个执行体在第一个信噪比条件下执行后得到的误帧率
    
    SC_decoder_conditions = zeros(length(ebn0),total_frame_num);
    BP_decoder_conditions = zeros(length(ebn0),total_frame_num);
    SCAN_decoder_conditions = zeros(length(ebn0),total_frame_num);
    SCL_decoder_conditions = zeros(length(ebn0),total_frame_num);
    SSC_decoder_conditions = zeros(length(ebn0),total_frame_num);

    for j = 1:length(ebn0)
        
        % DHR polar码仿真 
         [ThreeSystemBERNum , ThreeSystemFERNum ,FourSystemBERNum , FourSystemFERNum,FiveSystemBERNum , FiveSystemFERNum, ...
            ThreeSystemBER ,ThreeSystemFER, FourSystemBER ,FourSystemFER, FiveSystemBER,FiveSystemFER, TotalExecutorsBERNum , TotalExecutorsFERNum ,...
            TotalExecutorsBER , TotalExecutorsFER ,  EachFrameExecutorsBERs]  =     ...
            SingleSNRSimulationAttack1(N,K(jj),ebn0(j),total_frame_num,max_frame_num,construction_method,   ...
            bp_iter_num,scan_iter_num,scl_list_size,crc_size,decoder_tree_initial, G_set, B_set);
%          [SystemBERNum , SystemFERNum , SystemBER , SystemFER , TotalExecutorsBERNum , TotalExecutorsFERNum ,...
%             TotalExecutorsBER , TotalExecutorsFER ,  EachFrameExecutorsBERs]  =     ...
%             SingleSNRSimulationAttack2(N,K(jj),ebn0(j),total_frame_num,max_frame_num,construction_method,   ...
%             bp_iter_num,scan_iter_num,scl_list_size,crc_size,decoder_tree_initial, G_set, B_set);
    
        SystemBERNums(1,j) = ThreeSystemBERNum;
        SystemFERNums(1,j) = ThreeSystemFERNum;
        SystemBERs(1,j) = ThreeSystemBER;
        SystemFERs(1,j) = ThreeSystemFER;

        SystemBERNums(2,j) = FourSystemBERNum;
        SystemFERNums(2,j) = FourSystemFERNum;
        SystemBERs(2,j) = FourSystemBER;
        SystemFERs(2,j) = FourSystemFER;

        SystemBERNums(3,j) = FiveSystemBERNum;
        SystemFERNums(3,j) = FiveSystemFERNum;
        SystemBERs(3,j) = FiveSystemBER;
        SystemFERs(3,j) = FiveSystemFER;

    
        fprintf(' \n 3余度的DHR系统本次运行共执行%7d 个块/帧，即%7d 个码数。在码率为：%7d ，信噪比为：%7d 的环境下 总误码数为：%7d ，总误帧数为：%7d ，系统误码率为：%7d ，系统误帧率为：%7d 。\n ',...
            total_frame_num , total_frame_num*K(jj) , Rc , ebn0(j) , SystemBERNums(1,j) , SystemFERNums(1,j) , SystemBERs(1,j) , SystemFERs(1,j));
    
       for i = 1:5
            ComparativeExecutorsBER(i,j) = TotalExecutorsBER(i,1);
            ComparativeExecutorsFER(i,j) = TotalExecutorsFER(i,1);
            ComparativeExecutorsBERNum(i,j) = TotalExecutorsBERNum(i,1);
            ComparativeExecutorsFERNum(i,j) = TotalExecutorsFERNum(i,1);
       end




%        SC_decoder_conditions(j,:) = SC_decoder_condition(:);
%        BP_decoder_conditions(j,:) = BP_decoder_condition(:);
%        SCAN_decoder_conditions(j,:) = SCAN_decoder_condition(:);
%        SCL_decoder_conditions(j,:) = SCL_decoder_condition(:);
%        SSC_decoder_conditions(j,:) = SSC_decoder_condition(:);
        
        

        if K(jj) == 128 && ebn0(j) == 2
            figure(1);
            
            plot(1:1:total_frame_num,EachFrameExecutorsBERs(6,:),'m-.','LineWidth',1.5,'MarkerSize',6)
            hold on;
            plot(1:1:total_frame_num,EachFrameExecutorsBERs(1,:),'b-.','LineWidth',1.5,'MarkerSize',6)
            hold on;
            plot(1:1:total_frame_num,EachFrameExecutorsBERs(2,:),'g-.','LineWidth',1.5,'MarkerSize',6)
            hold on;
            plot(1:1:total_frame_num,EachFrameExecutorsBERs(3,:),'c-.','LineWidth',1.5,'MarkerSize',6)
            hold on;
            plot(1:1:total_frame_num,EachFrameExecutorsBERs(4,:),'r-.','LineWidth',1.5,'MarkerSize',6)
            hold on;
            plot(1:1:total_frame_num,EachFrameExecutorsBERs(4,:),'k-.','LineWidth',1.5,'MarkerSize',6)
            hold on;
            title('码率为0.5，信噪比为2时，系统的实时误码率');
            xlabel('时长（一帧运行的时间）')
            ylabel('误码率')
            legend('BER of DHR polar decoder','BER of SC polar decoder','BER of BP polar decoder' ,...
                'BER of SCAN polar decoder','BER of SCL polar decoder','BER of SSC polar decoder')

            figure(7);
            plot(1:1:total_frame_num,EachFrameExecutorsBERs(6,:),'m-.','LineWidth',1.5,'MarkerSize',6)
            hold on;
            plot(1:1:total_frame_num,EachFrameExecutorsBERs(7,:),'b-.','LineWidth',1.5,'MarkerSize',6)
            hold on;
            plot(1:1:total_frame_num,EachFrameExecutorsBERs(8,:),'g-.','LineWidth',1.5,'MarkerSize',6)
            hold on;
            title('码率为0.5，信噪比为2时，不同冗余度的dhr系统的实时误码率');
            xlabel('时长（一帧运行的时间）')
            ylabel('误码率')
            legend('BER of 3 Redundancy DHR','BER of 4 Redundancy DHR','BER of 5 Redundancy DHR')


        end

        

        if K(jj) == 128
          
            figure(3);
            if ebn0(j) == 1
                subplot(2,2,1);
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(6,:),'m-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(1,:),'b-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(2,:),'g-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(3,:),'c-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(4,:),'r-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(4,:),'k-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                xlabel('时长（一帧运行的时间）')
                ylabel('误码率')
                title('码率为0.5，信噪比为1时，系统的实时误码率');
                legend('BER of DHR polar decoder','BER of SC polar decoder','BER of BP polar decoder' ,...
                'BER of SCAN polar decoder','BER of SCL polar decoder','BER of SSC polar decoder')
            end
            if ebn0(j) == 2
                subplot(2,2,2);
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(6,:),'m-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(1,:),'b-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(2,:),'g-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(3,:),'c-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(4,:),'r-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(4,:),'k-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                xlabel('时长（一帧运行的时间）')
                ylabel('误码率')
                title('码率为0.5，信噪比为2时，系统的实时误码率');
                legend('BER of DHR polar decoder','BER of SC polar decoder','BER of BP polar decoder' ,...
                'BER of SCAN polar decoder','BER of SCL polar decoder','BER of SSC polar decoder')
            end
            if ebn0(j) == 2.5
                subplot(2,2,3);
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(6,:),'m-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(1,:),'b-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(2,:),'g-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(3,:),'c-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(4,:),'r-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(4,:),'k-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                xlabel('时长（一帧运行的时间）')
                ylabel('误码率')
                title('码率为0.5，信噪比为2.5时，系统的实时误码率');
                legend('BER of DHR polar decoder','BER of SC polar decoder','BER of BP polar decoder' ,...
                'BER of SCAN polar decoder','BER of SCL polar decoder','BER of SSC polar decoder')
            end
            if ebn0(j) == 3
                subplot(2,2,4);
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(6,:),'m-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(1,:),'b-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(2,:),'g-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(3,:),'c-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(4,:),'r-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                plot(1:1:total_frame_num,EachFrameExecutorsBERs(4,:),'k-.','LineWidth',1.5,'MarkerSize',6)
                hold on;
                xlabel('时长（一帧运行的时间）')
                ylabel('误码率')
                title('码率为0.5，信噪比为3时，系统的实时误码率');
                legend('BER of DHR polar decoder','BER of SC polar decoder','BER of BP polar decoder' ,...
                'BER of SCAN polar decoder','BER of SCL polar decoder','BER of SSC polar decoder')
            end
            sgtitle('码率为0.5时，系统在不同信噪比环境下的实时误码率');
        end

        if ebn0(j) == 2
            figure(4);
            subplot(length(K)/2,2,jj);  
            plot(1:1:total_frame_num,EachFrameExecutorsBERs(6,:),'m-.','LineWidth',1.5,'MarkerSize',6)
            hold on;
            plot(1:1:total_frame_num,EachFrameExecutorsBERs(1,:),'b-.','LineWidth',1.5,'MarkerSize',6)
            hold on;
            plot(1:1:total_frame_num,EachFrameExecutorsBERs(2,:),'g-.','LineWidth',1.5,'MarkerSize',6)
            hold on;
            plot(1:1:total_frame_num,EachFrameExecutorsBERs(3,:),'c-.','LineWidth',1.5,'MarkerSize',6)
            hold on;
            plot(1:1:total_frame_num,EachFrameExecutorsBERs(4,:),'r-.','LineWidth',1.5,'MarkerSize',6)
            hold on;
            plot(1:1:total_frame_num,EachFrameExecutorsBERs(4,:),'k-.','LineWidth',1.5,'MarkerSize',6)
            hold on;
            title('码率：',Rc);
            sgtitle('信噪比为2时，系统在不同码率下的实时误码率');
            xlabel('时长（一帧运行的时间）')
            ylabel('误码率')
%             ylim([-0.01 1.01])
            legend('BER of DHR polar decoder','BER of SC polar decoder','BER of BP polar decoder' ,...
                'BER of SCAN polar decoder','BER of SCL polar decoder','BER of SSC polar decoder')
            hold on;
            grid on;

            figure(9);
            subplot(length(K)/2,2,jj);  
            plot(1:1:total_frame_num,EachFrameExecutorsBERs(6,:),'m-.','LineWidth',1.5,'MarkerSize',6)
            hold on;
            plot(1:1:total_frame_num,EachFrameExecutorsBERs(7,:),'b-.','LineWidth',1.5,'MarkerSize',6)
            hold on;
            plot(1:1:total_frame_num,EachFrameExecutorsBERs(8,:),'g-.','LineWidth',1.5,'MarkerSize',6)
            hold on;
           title('码率：',Rc);
            sgtitle('信噪比为2时，不同冗余度的dhr系统在不同码率下的实时误码率');
            xlabel('时长（一帧运行的时间）')
            ylabel('误码率')
%             ylim([-0.01 1.01])
            legend('BER of 3 Redundancy DHR','BER of 4 Redundancy DHR','BER of 5 Redundancy DHR')
            hold on;
            grid on;
        end

    end

    if K(jj) == 128 
        figure(2);
        
        plot(ebn0,SystemBERs(1,:),'m-s','LineWidth',1.5,'MarkerSize',6)
        hold on;
        plot(ebn0,ComparativeExecutorsBER(1,:),'b-*','LineWidth',1.5,'MarkerSize',6)
        hold on;
        plot(ebn0,ComparativeExecutorsBER(2,:),'g-d','LineWidth',1.5,'MarkerSize',6)
        hold on;
        plot(ebn0,ComparativeExecutorsBER(3,:),'c-s','LineWidth',1.5,'MarkerSize',6)
        hold on;
        plot(ebn0,ComparativeExecutorsBER(4,:),'r-.','LineWidth',1.5,'MarkerSize',6)
        hold on;
        plot(ebn0,ComparativeExecutorsBER(5,:),'k-p','LineWidth',1.5,'MarkerSize',6)
        hold on;
        title('码率为0.5时，系统在不同信噪比环境下的误码率');
        xlabel('信噪比 (dB)')
        ylabel('误码率')
%         ylim([-0.01 1.01])
        legend('BER of DHR polar decoder','BER of SC polar decoder','BER of BP polar decoder' ,...
            'BER of SCAN polar decoder','BER of SCL polar decoder','BER of SSC polar decoder')
        hold on;
        grid on;


        figure(8);
        plot(ebn0,SystemBERs(1,:),'m-s','LineWidth',1.5,'MarkerSize',6)
        hold on;
        plot(ebn0,SystemBERs(2,:),'b-*','LineWidth',1.5,'MarkerSize',6)
        hold on;
        plot(ebn0,SystemBERs(3,:),'g-d','LineWidth',1.5,'MarkerSize',6)
        hold on;
        title('码率为0.5时，不同冗余度的dhr系统在不同信噪比环境下的误码率');
        xlabel('信噪比 (dB)')
        ylabel('误码率')
        legend('BER of 3 Redundancy DHR','BER of 4 Redundancy DHR','BER of 5 Redundancy DHR');
        hold on;
        grid on;
    end

    % 画图
    figure(5);
    subplot(length(K)/2,2,jj);     % 2个图片摆成1列，第三个参数是指第几个小图
    semilogy(ebn0,SystemBERs(1,:),'m-s','LineWidth',1.5,'MarkerSize',6)
    hold on;
    semilogy(ebn0,ComparativeExecutorsBER(1,:),'b-*','LineWidth',1.5,'MarkerSize',6)
    hold on;
    semilogy(ebn0,ComparativeExecutorsBER(2,:),'g-d','LineWidth',1.5,'MarkerSize',6)
    hold on;
    semilogy(ebn0,ComparativeExecutorsBER(3,:),'c-s','LineWidth',1.5,'MarkerSize',6)
    hold on;
    semilogy(ebn0,ComparativeExecutorsBER(4,:),'r-.','LineWidth',1.5,'MarkerSize',6)
    hold on;
    semilogy(ebn0,ComparativeExecutorsBER(5,:),'k-p','LineWidth',1.5,'MarkerSize',6)
    hold on;
    title('码率：',Rc);
    sgtitle('系统在不同码率下的实时误码率');
    xlabel('信噪比 (dB)')
    ylabel('误码率')
    ylim([-0.01 1.01])
    legend('BER of DHR polar decoder','BER of SC polar decoder','BER of BP polar decoder' ,...
        'BER of SCAN polar decoder','BER of SCL polar decoder','BER of SSC polar decoder')
    hold on;
    grid on;
    
    
    
%     subplot(length(K),2,2*jj);
%     semilogy(ebn0,SystemFERs,'m-s','LineWidth',1.5,'MarkerSize',6)
%     hold on;
%     semilogy(ebn0,ComparativeExecutorsFER(1,:),'b-*','LineWidth',1.5,'MarkerSize',6)
%     hold on;
%     semilogy(ebn0,ComparativeExecutorsFER(2,:),'g-d','LineWidth',1.5,'MarkerSize',6)
%     hold on;
%     semilogy(ebn0,ComparativeExecutorsFER(3,:),'c-s','LineWidth',1.5,'MarkerSize',6)
%     hold on;
%     semilogy(ebn0,ComparativeExecutorsFER(4,:),'r-.','LineWidth',1.5,'MarkerSize',6)
%     hold on;
%     semilogy(ebn0,ComparativeExecutorsFER(5,:),'k-p','LineWidth',1.5,'MarkerSize',6)
%     hold on;
%     title('码率：',Rc);
%     xlabel('Eb/No (dB)')
%     ylabel('SystemFER')
%     ylim([-0.01 1.01])
%     legend('FER of DHR polar decoder','FER of SC polar decoder','FER of BP polar decoder' ,...
%         'FER of SCAN polar decoder','FER of SCL polar decoder','FER of SSC polar decoder')
%     hold on;
%     grid on;


    figure(6);
    subplot(length(K)/2,2,jj);     % 2个图片摆成1列，第三个参数是指第几个小图
    plot(ebn0,SystemBERs(1,:),'m-s','LineWidth',1.5,'MarkerSize',6)
    hold on;
    plot(ebn0,ComparativeExecutorsBER(1,:),'b-*','LineWidth',1.5,'MarkerSize',6)
    hold on;
    plot(ebn0,ComparativeExecutorsBER(2,:),'g-d','LineWidth',1.5,'MarkerSize',6)
    hold on;
    plot(ebn0,ComparativeExecutorsBER(3,:),'c-s','LineWidth',1.5,'MarkerSize',6)
    hold on;
    plot(ebn0,ComparativeExecutorsBER(4,:),'r-.','LineWidth',1.5,'MarkerSize',6)
    hold on;
    plot(ebn0,ComparativeExecutorsBER(5,:),'k-p','LineWidth',1.5,'MarkerSize',6)
    hold on;
    title('码率：',Rc);
    sgtitle('系统在不同码率下的实时误码率');
    xlabel('信噪比 (dB)')
    ylabel('误码率')
%     ylim([-0.01 1.01])
    legend('BER of DHR polar decoder','BER of SC polar decoder','BER of BP polar decoder' ,...
        'BER of SCAN polar decoder','BER of SCL polar decoder','BER of SSC polar decoder')
    hold on;
    grid on;
    
    
%     subplot(length(K),2,2*jj);
%     plot(ebn0,SystemFERs,'m-s','LineWidth',1.5,'MarkerSize',6)
%     hold on;
%     plot(ebn0,ComparativeExecutorsFER(1,:),'b-*','LineWidth',1.5,'MarkerSize',6)
%     hold on;
%     plot(ebn0,ComparativeExecutorsFER(2,:),'g-d','LineWidth',1.5,'MarkerSize',6)
%     hold on;
%     plot(ebn0,ComparativeExecutorsFER(3,:),'c-s','LineWidth',1.5,'MarkerSize',6)
%     hold on;
%     plot(ebn0,ComparativeExecutorsFER(4,:),'r-.','LineWidth',1.5,'MarkerSize',6)
%     hold on;
%     plot(ebn0,ComparativeExecutorsFER(5,:),'k-p','LineWidth',1.5,'MarkerSize',6)
%     hold on;
%     title('码率：',Rc);
%     xlabel('Eb/No (dB)')
%     ylabel('SystemFER')
%     ylim([-0.01 1.01])
%     legend('FER of DHR polar decoder','FER of SC polar decoder','FER of BP polar decoder' ,...
%         'FER of SCAN polar decoder','FER of SCL polar decoder','FER of SSC polar decoder')
%     hold on;
%     grid on;


end







toc

